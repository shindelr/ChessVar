These assets are a subset of what is available from Kenney.nl.

If you like his work, please go support is by purchasing his full asset packs
at https://kenney.nl/

class vertex:
    default_projection = ":resources:shaders/texture_default_projection_vs.glsl"


class fragment:
    texture = ":resources:shaders/texture_fs.glsl"
